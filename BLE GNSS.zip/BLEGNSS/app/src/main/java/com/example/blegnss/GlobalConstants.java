package com.example.blegnss;

public class GlobalConstants {
    public static final String INVALID = "INVALID";
    public static final String ANOTHER_DATA = "ANOTHER_DATA";
    public static final String NEWLOCATION_ID = "new_location";
}
