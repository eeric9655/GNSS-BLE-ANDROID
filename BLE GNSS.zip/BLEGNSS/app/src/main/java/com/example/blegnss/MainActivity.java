package com.example.blegnss;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements MapsFragment.OnDataPass{
    MapsFragment frag_maps;
    Button buttonScan;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private static final String TAG = "MainActivity";
    private static final int REQUEST_ENABLE_BT = 1;
    private static final int PERMISSION_REQUEST_CODE = 2;

    private BluetoothAdapter bluetoothAdapter;
    private ArrayAdapter<String> deviceListAdapter;
    private ArrayList<String> deviceList;
    private BluetoothGatt bluetoothGatt;
    private List<BluetoothDevice> bluetoothDevices;
    private Map<String, BluetoothGatt> connectedDevices;
    ListView listViewDevices;
    boolean isCommunicating = false;
    int loading=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        Button btn = findViewById(R.id.btn_map);
        deviceList = new ArrayList<>();
        bluetoothDevices = new ArrayList<>();
        connectedDevices = new HashMap<>();
        deviceListAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, deviceList);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent inMaps  = new Intent(MainActivity.this,MapsActivity2.class);
                //startActivity(inMaps);
                //frag = new MapsFragment();
                replaceFragment(frag_maps);
                stopScan();
            }
        });
        int loc_per = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION);
        if (loc_per != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
        BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bluetoothManager.getAdapter();

        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        listViewDevices = findViewById(R.id.list_view_devices);
        listViewDevices.setAdapter(deviceListAdapter);

        buttonScan = findViewById(R.id.button_scan);
        buttonScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermissions();
                //checkPermissionsAndStartScanning();
                startScanning();
                Log.e("BT check","PUSHED");
                listViewDevices.setVisibility(View.VISIBLE);
                //Toast.makeText(MainActivity.this,"Pushed",Toast.LENGTH_LONG).show();
            }
        });
        //buttonScan.setText(formatLocationData("@Lat:12.355512@Lng:102.211252"));
        listViewDevices.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                connectToDevice(position);
            }
        });
        // Request location permission if not already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_REQUEST_CODE);
        }
        frag_maps = new MapsFragment();
        replaceFragment(frag_maps);
        /*
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Pass new data to MapsFragment
                onDataPass("Updated location data from MainActivity");
            }
        }, 5000); // Delay for 5 seconds
        */
    }

    @SuppressLint("MissingPermission")
    private void startScanning() {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            deviceList.clear();
            bluetoothDevices.clear();
            updateDeviceList();
            bluetoothAdapter.getBluetoothLeScanner().startScan(leScanCallback);
            Toast.makeText(this, "Scanning for devices...", Toast.LENGTH_SHORT).show();
        }
    }

    public void replaceFragment(Fragment frag) {
        FragmentManager frag_mnr = getSupportFragmentManager();
        FragmentTransaction fr_transaction = frag_mnr.beginTransaction();
        fr_transaction.replace(R.id.frag_main, frag);
        fr_transaction.addToBackStack(null);
        fr_transaction.commit();
    }
    @SuppressLint("MissingPermission")
    private ScanCallback leScanCallback = new ScanCallback() {

        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            BluetoothDevice device = result.getDevice();
            String deviceInfo = device.getName() + " - " + device.getAddress();
            if (device.getName() != null && !deviceList.contains(deviceInfo)) {
                deviceList.add(deviceInfo);
                bluetoothDevices.add(device);
                updateDeviceList();
            }
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            super.onBatchScanResults(results);
            for (ScanResult result : results) {
                BluetoothDevice device = result.getDevice();
                String deviceInfo = device.getName() + " - " + device.getAddress();
                if (device.getName() != null && !deviceList.contains(deviceInfo)) {
                    deviceList.add(deviceInfo);
                    bluetoothDevices.add(device);
                    updateDeviceList();
                }
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);
            Toast.makeText(MainActivity.this, "Scan failed with code: " + errorCode, Toast.LENGTH_SHORT).show();
        }
    };
    @SuppressLint("MissingPermission")
    private void updateDeviceList() {
        deviceListAdapter.clear();
        for (String address : connectedDevices.keySet()) {
            BluetoothDevice device = connectedDevices.get(address).getDevice();
            deviceListAdapter.add("[Connected] " + device.getName() + " - " + device.getAddress());

        }
        for (BluetoothDevice device : bluetoothDevices) {
            deviceListAdapter.add(device.getName() + " - " + device.getAddress());
        }
        deviceListAdapter.notifyDataSetChanged();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_OK) {
            startScanning();
        }
    }
    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        new String[]{
                                Manifest.permission.BLUETOOTH_SCAN,
                                Manifest.permission.BLUETOOTH_CONNECT,
                                Manifest.permission.ACCESS_FINE_LOCATION},
                        PERMISSION_REQUEST_CODE);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        PERMISSION_REQUEST_CODE);
            }
        }
    }

    private void checkPermissionsAndStartScanning() {
        Log.e("BT check","Pushed Permession");
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
            }, PERMISSION_REQUEST_CODE);
            //Toast.makeText(MainActivity.this,"NOT GRANTED",Toast.LENGTH_LONG).show();
            Log.e("BT check","NOT GRANTED");
        } else {
            //Toast.makeText(MainActivity.this,"Scanning...",Toast.LENGTH_LONG).show();
            Log.e("BT check","SCANNING...");
            startScanning();
        }
    }
    @SuppressLint("MissingPermission")
    private void enableBluetooth() {
        if (bluetoothAdapter != null && !bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }
    }

    @SuppressLint("MissingPermission")
    private void disableBluetooth() {
        if (bluetoothAdapter != null && bluetoothAdapter.isEnabled()) {
            bluetoothAdapter.disable();
            Toast.makeText(this, "Bluetooth disabled", Toast.LENGTH_SHORT).show();
        }
    }
    @SuppressLint("MissingPermission")
    private void connectToDevice(int position) {
        BluetoothDevice device;
        if (position < connectedDevices.size()) {
            device = connectedDevices.get(position).getDevice();
            Toast.makeText(this, "Already connected to " + device.getName(), Toast.LENGTH_SHORT).show();
            return;
        } else {
            device = bluetoothDevices.get(position - connectedDevices.size());
        }
        BluetoothGatt bluetoothGatt = device.connectGatt(this, false, bluetoothGattCallback);
        connectedDevices.put(device.getAddress(), bluetoothGatt);
        Toast.makeText(this, "Connecting to " + device.getName(), Toast.LENGTH_SHORT).show();
    }
    @SuppressLint("MissingPermission")
    private final BluetoothGattCallback bluetoothGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            if (newState == BluetoothGatt.STATE_CONNECTED) {
                Log.i(TAG, "Connected to GATT server.");
                gatt.discoverServices();
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Connected to " + gatt.getDevice().getName(), Toast.LENGTH_SHORT).show();
                    updateDeviceList();
                });
            } else if (newState == BluetoothGatt.STATE_DISCONNECTED) {
                Log.i(TAG, "Disconnected from GATT server.");
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Disconnected from " + gatt.getDevice().getName(), Toast.LENGTH_SHORT).show();
                    connectedDevices.remove(gatt.getDevice().getAddress());
                    updateDeviceList();
                });
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.i(TAG, "Services discovered.");
                // Assuming the device has a specific characteristic UUID you want to read or enable notifications for
                UUID serviceUUID=null;//=UUID.fromString("4fafc201-1fb5-459e-8fcc-c5c9c331914b");
                UUID characteristicUUID = null;// = UUID.fromString("beb5483e-36e1-4688-b7f5-ea07361b26a8");
                List<BluetoothGattService> gattservices = gatt.getServices();
                for (BluetoothGattService gattService : gattservices) {
                    serviceUUID = gattService.getUuid();
                    Log.i(TAG, "Service UUID: " + serviceUUID.toString());

                    List<BluetoothGattCharacteristic> gattCharacteristics = gattService.getCharacteristics();
                    for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {
                        characteristicUUID = gattCharacteristic.getUuid();
                        Log.i(TAG, "Characteristic UUID: " + characteristicUUID.toString());
                    }
                }
                BluetoothGattService service = gatt.getService(serviceUUID);
                if (service != null) {
                    BluetoothGattCharacteristic characteristic = service.getCharacteristic(characteristicUUID);
                    if (characteristic != null) {
                        // Read the characteristic
                        gatt.readCharacteristic(characteristic);

                        // Enable notifications for the characteristic
                        gatt.setCharacteristicNotification(characteristic, true);
                        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
                        if (descriptor != null) {
                            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                            gatt.writeDescriptor(descriptor);
                        }
                        stopScan();
                        listViewDevices.setVisibility(View.GONE);
                    } else {
                        Log.w(TAG, "Characteristic not found.");
                    }
                } else {
                    Log.w(TAG, "Service not found.");
                }
            } else {
                Log.w(TAG, "onServicesDiscovered received: " + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicRead(gatt, characteristic, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                handleCharacteristicData(characteristic);
            }
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.i(TAG, "Characteristic written: " + characteristic.getUuid().toString());
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);
            handleCharacteristicData(characteristic);
        }

        @Override
        public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorRead(gatt, descriptor, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.i(TAG, "Descriptor read: " + descriptor.getUuid().toString());
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.i(TAG, "Descriptor written: " + descriptor.getUuid().toString());
            }
        }
    };

    private void handleCharacteristicData(BluetoothGattCharacteristic characteristic) {
        // Handle the received characteristic data here
        String newLocation = characteristic.getStringValue(0); // Adjust based on data format
        //runOnUiThread(() -> Toast.makeText(MainActivity.this, "Received data: " + newLocation, Toast.LENGTH_LONG).show());
        sendToFragment(formatLocationData(newLocation));
        stopScan();
        isCommunicating = !isCommunicating;
        if(isCommunicating)buttonScan.setBackgroundColor(Color.RED);
        else buttonScan.setBackgroundColor(Color.GREEN);
        loading++;
        if(loading==1)buttonScan.setText("Loading.");//formatLocationData(newLocation));
        else if(loading==2)buttonScan.setText("Loading..");
        else if(loading==3)buttonScan.setText("Loading...");
        if(loading>3) loading =0;
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startScanning();
            } else {
                Toast.makeText(this, "Permissions are required for BLE scanning", Toast.LENGTH_SHORT).show();
            }
        }
    }
    @SuppressLint("MissingPermission")
    private void stopScan(){
        bluetoothAdapter.getBluetoothLeScanner().stopScan(leScanCallback);
        listViewDevices.setVisibility(View.GONE);
    }
    private void sendToFragment(String newLoc){
        Bundle bundle = new Bundle();
        bundle.putString(GlobalConstants.NEWLOCATION_ID, newLoc);
        frag_maps.setArguments(bundle);
        onDataPass(newLoc);
        Log.e("Sending data : ", " to Maps fragment");
    }
    private String formatLocationData(String locationData) {
        //@Lat:12.355512@Lng:102.211252
        String latitude = "";
        String longitude = "";
        if(locationData.contains("INVAL")){
            return GlobalConstants.INVALID;
        }else if(!locationData.contains("@")){
            return GlobalConstants.ANOTHER_DATA;
        }
        else{
            String[] parts = locationData.split("@");
            /*for (String part : parts) {
                if (part.startsWith("Lat:")) {
                    latitude = part.substring(4);
                } else if (part.startsWith("Lng:")) {
                    longitude = part.substring(4);
                }
            }*/
            //buttonScan.setText(parts[0]+":"+parts[2]);
            latitude = parts[1];
            longitude = parts[2];
        }
        return latitude + "," + longitude;
    }
    @Override
    public void onDataPass(String data) {
        if (frag_maps != null) {
            frag_maps.updateTextView(data);
        }
    }
}